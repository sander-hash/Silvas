<?PHP
// dit bestand, routes.php defineert alle mogelijke urls die gebruikers kunnen gebruiken
// hiervoor gebruiken we de functie Defineroute.
// defineRoute( string url with vars, array userroles, string controllername, string controller action);
// url with vars = de url die gebruikt wordt, deze kan variabelen bevatten.
// voorbeeld: /groups/int:group_id/string:filter/
// userroles = een array met user roles (groepen) die de url mogen aanroepen
// controllername = de naam van de controller die aangeroepen moet worden
// controller action = de functie binnen de controller die uitgevoerd moet worden
defineRoute("/", array("visitors") , "controllerGeneralInfo", "actionStageBijSilvas");
defineRoute("/solliciteren-bij-silvas", array("allusers", "visitors") , "controllerSolliciteren", "showSolliciterenForm");
defineRoute("/solliciteren-bij-silvas/stagiairToevoegen/int:id", array("begeleiders") , "controllerUsers", "addStagiair");
defineRoute("/solliciteren-bij-silvas/verstuurformulier", array("allusers", "visitors") , "controllerSolliciteren", "saveForm");
defineRoute("/onze-huisregels", array("visitors") , "controllerGeneralInfo", "showHuisregels");

//Alle routes te maken met evaluaties
defineRoute("/evaluatie", array("begeleiders", "stagiaires") , "controllerEvaluatie", "showEvaluatie");
defineRoute("/evaluatie/toevoegen", array("begeleiders") , "controllerUsers", "showModalToevoegen");
defineRoute("/evaluatie/showEvaluatieToevoegen/int:user_id", array("allusers") , "controllerEvaluatie", "showModalEvaluatieToevoegen");
defineRoute("/evaluatie/showEvaluatie/int:id", array("allusers") , "controllerEvaluatie", "showModalEvaluatie");
defineRoute("/evaluatie/showEvaluatieStagiair/int:user_id", array("allusers") , "controllerEvaluatie", "showEvaluatieStagiair");
defineRoute("/evaluatie/evaluatieToevoegen/int:id", array("begeleiders") , "controllerEvaluatie", "addEvaluatie");
defineRoute("/evaluatie/eindEvaluatieToevoegen/int:user_id", array("begeleiders") , "controllerEvaluatie", "showEindEvaluatie");
defineRoute("/evaluatie/opmerkingVerwijderen/int:id/int:user_id", array("begeleiders") , "controllerEvaluatie", "verwijderOpmerking");
defineRoute("/evaluatie/stagiairToevoegen", array("begeleiders") , "controllerUsers", "addUser");
defineRoute("/evaluatie/opmerkingToevoegen/int:user_id", array("stagiaires", "begeleiders") , "controllerEvaluatie", "opmerkingToevoegen");
defineRoute("/evaluatie/opmerkingToevoegenModal/int:id/int:user_id", array("stagiaires", "begeleiders") , "controllerEvaluatie", "showModalOpmerkingToevoegen");
defineRoute("/evaluatie/stagiairAfronden/int:ID/int:user_id", array("begeleiders") , "controllerUsers", "stagiarAfronden");
defineRoute("/evaluatie/verwijderen/int:record_id/int:user_id", array("begeleiders") , "controllerUsers", "doDeleteUser");
defineRoute("/evaluatie/evaluatieVerwijderen/int:id/int:user_id", array("begeleiders") , "controllerEvaluatie", "verwijderEvaluatie");
defineRoute("/solliciteren-bij-silvas/sollicitatieVerwijderen/int:id", array("begeleiders") , "controllerSolliciteren", "sollicitatieVerwijderen");


//Alle routes te maken met profiel van de stagiair
defineRoute("/profile/inzien/int:user_id", array("begeleiders") , "controllerUsers", "inzienProfielStagiair");
defineRoute("/profile", array( "stagiaires") , "controllerUsers", "profiel");
defineRoute("/profile/profielBewerken/int:ID", array( "stagiaires") , "controllerUsers", "profielBewerken");
defineRoute("/evaluatie/avatarUpload", array("stagiaires") , "controllerUsers", "uploadFile");
defineRoute("/evaluatie/avatarOphalen", array("stagiaires") , "controllerUsers", "ophalenFile");

// Alle routes te maken met inloggen / uitloggen
defineRoute("/inloggen", array("visitors") , "controllerLogin", "showLoginPage","templateLogin");
defineRoute("/inloggen/string:reason", array("visitors") , "controllerLogin", "showLoginPage","templateLogin");
defineRoute("/uitloggen", array("allusers") , "controllerLogin", "doLogout");
defineRoute("/", array("visitors"), "controllerLogin", "showLoginPage","templateLogin");

defineRoute("/users/showchangepassword", array("allusers"), "appChangePassword", "showChangePasswordStep1","templateAppDefault");
defineRoute("/users/changepassword/int:user_id", array("allusers"), "appChangePassword", "showChangePasswordStep2","templateAppDefault");