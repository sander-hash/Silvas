<?PHP

//! extend de gewenste template om daar vanaf te werken
class templateMain extends templateDefault
{
  function __construct()
  {
    
    $this->addHead('<link href="signin.css" rel="stylesheet">' ,1);
  }


    function body()
    {
        global $app;
        new NavBar();
        ?>

        <main id="app-main" class="p-3" style="margin-top:75px;">
          <?PHP print $app->content; ?>
        </main>
        <?PHP
    }
}

