<?PHP

class navBar
{
    function __construct()
    {
        $req_uri = $_SERVER['REQUEST_URI'];
        $modelFWGroups = new modelFWGroups;
        $modelFWUsers = new modelFWUsers;
        $models = new modelUser;
        $currentUserRole = $modelFWGroups->getRolesOfUser(0,true);
        
    ?>
    <nav class="navbar navbar-expand-md navbar-light fixed-top bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="/">
          <img src="http://stage.silvas.dev/wp-content/uploads/sites/5/2021/12/photo.png" class="rounded-circle">
        </a>
        <?php
        if(in_array("allusers",$currentUserRole)){
        $appSwitcher = new appSwitcher();
              $appSwitcher->html();
        }
              ?>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon "></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="nav navbar-nav me-auto mb-2 mb-md-0">
      
          
            
            <li class="nav-item">
            <?php
            if($req_uri == "/" ){
                ?> <a class="nav-link active" href="/">Stage bij silvas</a><?php
              }else{
               ?> <a class="nav-link" href="/">Stage bij silvas</a> <?php
              }?>
            </li>
            <li class="nav-item">
            <?php if(!in_array("stagiaires",$currentUserRole)){
              if($req_uri == "/solliciteren-bij-silvas" ){
                ?> <a class="nav-link active" href="/solliciteren-bij-silvas">Solliciteren</a><?php
              }else{
               ?> <a class="nav-link" href="/solliciteren-bij-silvas">Solliciteren</a> <?php
              }
            }
              ?>
            </li>
            <?PHP 


              if(in_array("allusers",$currentUserRole)){
                ?>
                <li class="nav-item">
                  <?php if($req_uri == "/onze-huisregels" ){
                    ?> <a class="nav-link active" href="/onze-huisregels">Praktische info & huisregels</a><?php
                  }else{
                  ?> <a class="nav-link" href="/onze-huisregels">Praktische info & huisregels</a> <?php
                  }?>
                </li> 
                <li class="nav-item">
              <?php if($req_uri == "/evaluatie" ){
                    ?> <a class="nav-link active" href="/evaluatie">Evaluatie</a><?php
                  }else{
                  ?> <a class="nav-link" href="/evaluatie">Evaluatie</a> <?php
                  }?>
                </li>
                <?PHP 
              }
            ?>
          </ul>


          <?php    
          if(in_array("stagiaires",$currentUserRole)){ ?>
          <div id="showAvatar">
                  <?php
                        $class_files = new modelFWFiles();
                        $user_id = getUserId();
                        
                        $files = $class_files->getByMultipleKeys(array('user_id'=>$user_id));
                        foreach ($files as $file){
                        ?>
                            <img src="<?php print $class_files->getFileURL ($file->id) ?>" alt="Girl in a jacket" width="50" height="50" class="rounded-circle me-2">
                        <?php
                        } 
                    ?>
                </div>
            <script>
            var today = new Date()
            var curHr = today.getHours()
            if (curHr < 12) {
              var message = "Goedenmorgen"
            } else if (curHr < 18) {
              var message = "Goedenmiddag"
            } else {
              var message = "Goedenavond"
            }
            </script>
          <?PHP 
                $keys['user_id'] = $modelFWUsers->getActiveUserId();
                $modelUser = $models->getByMultipleKeys($keys);
                foreach($modelUser as $users){
                  ?><div style="margin-right:10px;"><?php
                  print $message = "<script>document.write(message)</script>" . " ";
                
                        print $users->voornaam . " " . $users->achternaam;
                      }
                  ?></div>
                  <?php            
                   $modelFWGroups = new modelFWGroups;
                   $currentUserRole = $modelFWGroups->getRolesOfUser(0,true);

              if(in_array("stagiaires",$currentUserRole)){
                $data['controller'] = '/profile';
                $jsframework = new JSFramework();
                $functionname = $jsframework->createCall($data, '', false, array());
                print $jsframework->createLink($functionname,'<i class="h5 bi bi-person-video2"></i>', "btn btn-primary btn-sm me-1","hideModal");
                
              }
            }
            
            $modelFWGroups = new modelFWGroups;
            $currentUserRole = $modelFWGroups->getRolesOfUser(0,true);



              if(in_array("allusers",$currentUserRole)){
                ?>
                 <p> &nbsp;  &nbsp;</p><?php
            $messenger = new frameworkMessage();
            $messenger->html(); ?>
                  <a class="btn btn-danger" href="/uitloggen">Uitloggen</a>
                <?PHP 
              }else{
                ?>
                  <a class="btn btn-success" href="/inloggen">Inloggen</a>
                <?PHP 
              }
            ?>

        </div>
      </div>
    </nav>
    <?PHP
    ?>


      <?php 
    }
}



