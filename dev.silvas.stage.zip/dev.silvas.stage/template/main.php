<?PHP

class templateAppDefault extends templateDefault
{
    function __construct()
    {
        parent::__construct();        
    }

    function html()
    {
        new NavBar();
        $this->container();

        ?>
        <style>@media screen and (max-width: 1150px) {
            .app_switcher_div {
                display: none !important;
            }
            .firstAndLastname {
                display: none !important;
            }
        }
        <?php

    }

    function body() {
        ?>
        <!-- start body -->
        <body class="d-flex flex-column h-100">
            <?PHP $this->html(); ?>    
            <?PHP $this->errormodals(); ?>
            <?PHP $this->warning(); ?>
            <?PHP $this->error(); ?>
            <?PHP $this->footer(); ?>
            <?PHP $this->afterfooter(); ?>
        </body>
        <!-- end body -->    
        <?PHP
        }

    function container()
    {        
        global $app;  
        ?>
<!-- Begin page content -->
<main class="flex-shrink-0">
<div class="container"><div style="margin-top: 5rem !important;">
    <?PHP print $app->content; ?>
  </div></div>
</main>
        <?PHP
    }

    function footer()
    {
        ?>
        <footer class="footer mt-auto py-3 bg-light">
  <div class="container">
    <span class="text-muted">Place sticky footer content here.</span>
  </div>
</footer>
<script src="https://getbootstrap.com/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<?PHP
    }

}
