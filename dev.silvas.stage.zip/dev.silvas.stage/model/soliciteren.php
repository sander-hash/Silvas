<?PHP 

class modelSolliciteren extends DefaultModel
{

    function __construct()
    {
        $this->connect("6397e34cd035", "password", "db", "localhost");

        // INT id
        // STRING data
        // INT ctime, default = 0; 
        // INT status , defautt 0 = Nog niet afgehandeld , 1 = afgehandeld niet goedgekeurd , 2 = afgehandeld goedgekeurd
        $this->setTableName("tbl_sollicitaties",false);
    }

}