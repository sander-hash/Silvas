<?PHP 

class modelUserInfo extends DefaultModel
{

    function __construct()
    {
        $this->connect("6397e34cd035", "password", "db", "localhost");

        // INT id
        // STRING data
        // INT ctime, default = 0; 
        // INT status , defautt 0 = Nog niet afgehandeld , 1 = afgehandeld niet goedgekeurd , 2 = afgehandeld goedgekeurd
        $this->setTableName("tbl_evaluatie",false);
    }
    function sortOnDate($user_id){



        $sqlline = "SELECT * FROM `tbl_evaluatie` 
                    WHERE `user_id` = $user_id
                    ORDER BY `datum` DESC";
       
        return $this->DB->get_results($sqlline);

    }
    function deleteEvaluaties($user_id){

        $sql="DELETE FROM `".$this->tableName."` WHERE user_id = $user_id";
        return $this->DB->get_results($sql);
    }

   

}