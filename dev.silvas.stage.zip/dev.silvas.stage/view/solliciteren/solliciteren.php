<?PHP 


class viewSolliciteren extends viewMain
{

    function showSolliciterenBijSilvas($params){

        global $app;
        ob_start();
        $modelGroups = new modelFWGroups();
        $currentUserRole = $modelGroups->getRolesOfUser(0,true);
        ?><div id="solliciteren"><?php
        if(!in_array("allusers",$currentUserRole)){
        print $this->showSollictatieForm();
        }

        if(in_array("begeleiders",$currentUserRole)){
        ?><h2 class="mt-2">Sollicitanten</h2><?
        print $this->showSollicitatieTable();
        print $this->showSilvasTable();
        }
        $content = ob_get_contents();
        ob_end_clean();
        return $content;

        ?></div><?php
        
    }
    function showSilvasTable(){
      // $model = new modelFWUsers();
      // $user_id = 329;
      //   $result = $model->getById($user_id);

      //   // print_r($silvasdb);

      //   $tabel = new Table();
      //   // voeg de kop regels toe
      //   $row = array();
      //   $row[] = "id";
      //   $row[] = "wp_id";
      //   $row[] = "customer id";
      //   $tabel->addHead($row);

      //       $user = get_userdata($result->wp_id);

      //       $row = array();
      //       $row[] = $result->id;
      //       $row[] = $result->wp_id;
      //       $row[] = $result->customer_id;
         
      //       $tabel->addRow($row);
  
        
      //   return $tabel->html();
    }

    function showSollicitatieTable(){

        $model = new modelSolliciteren();
        $modelCustomer = new modelFWCustomer();
        $model = $model->getAll();
        $tabel = new Table();
      
        $row = array();
        $row[] = "Voornaam";
        $row[] = "Achternaam";
        $row[] = "Email";
        $row[] = "School";
        $row[] = "Opleiding";
        $row[] = "Leerjaar";
        $row[] = "Opmerking";
        $row[] = "Bedrijf";
        $row[] = "";
        $row[] = "";
        $tabel->addHead($row);
  
        foreach($model as $results)
        {   
            // hier foreach je alle users die je op hebt gehaald door middel van de multiplekeys in een row
            $customer_id = $results->customer_id;
            $row = array();
            $row[] = $results->voornaam;
            $row[] = $results->achternaam;
            $row[] = $results->emailadres;
            $row[] = $results->school;
            $row[] = $results->opleiding;
            $row[] = $results->leerjaar;
            $row[] = $results->opmerking;
            $row[] = $modelCustomer->getCustomerName($customer_id);

            $jsframework = new JSFramework();
            $data['controller'] = '/solliciteren-bij-silvas/stagiairToevoegen/'.$results->id;

            
            $functionname = $jsframework->createCall($data, '', false, array());
            $button = $jsframework->createLink($functionname, "Toevoegen", "btn btn-primary btn-sm ms-1");

            $data['controller'] = '/solliciteren-bij-silvas/sollicitatieVerwijderen/'.$results->id;
            $confirmbox['heading'] = "Stagiair verwijderen";
            $confirmbox['body'] = "Weet je zeker dat je <strong>".$results->voornaam."</strong> wilt verwijderen? ";
            $confirmbox['cancel'] = "Annuleren";
            $confirmbox['continue'] = "Verwijderen";
            $functionname = $jsframework->createCall($data, '', false,  $confirmbox, array());
            
            
            $button .= $jsframework->createLink($functionname, "Verwijderen ", "btn btn-danger btn-sm ms-1");
            
            
            $row[] = $button;
            $tabel->addRow($row);
  
        }
        return $tabel->html();
      }

      function showSollictatieForm(){
        ?>
        
        <div class="container">
        <form id="sol_form">
        <h2>Solliciteren bij Silvas</h2>
        <div class="form-group">
        <label for="voornaamLabel">Voornaam</label>
        <input type="text" class="form-control" id="voornaam" placeholder="Voornaam" required>
      </div>
      <div class="form-group">
        <label for="achternaamLabel">Achternaam</label>
        <input type="text" class="form-control" id="achternaam" placeholder="Achternaam" required>
      </div>
      <div class="form-group">
        <label for="telefoonLabel">Email</label>
        <input type="email" class="form-control" id="email" placeholder="Email" required>
      </div>
      <div class="form-group">
        <label for="telefoon">School</label>
        <input type="text" class="form-control" id="school" placeholder="School" required>
      </div>
      <div class="form-group">
        <label for="telefoon">Opleiding</label>
        <input type="text" class="form-control" id="opleiding" placeholder="Opleiding" required>
      </div>
      <div class="form-group">
        <label for="opleiding">Leerjaar</label>
        <input type="text" class="form-control" id="leerjaar" placeholder="Leerjaar" required>
      </div>
      <div class="form-group">
        <label for="telefoon">Extra info</label>
        <input type="text" class="form-control" id="extra_info" placeholder="Extra info" required>
      </div>
      <br>

  <select id="customer_id" class="form-select" aria-label="Default select example">
  <option selected>Voor welk bedrijf solliciteer je?</option>
  <option value="31">Silvas</option>
  <option value="42">Schooltoday</option>
</select>

<br>
  
  
  <?php
  // hier haal de je alle data op uit de textboxes
        $data['controller'] = '/solliciteren-bij-silvas/verstuurformulier';  

        $validate['check'] = "min1";
        $validate['message'] = "Dit veld mag niet leeg zijn";
        $data['voornaam']['validate'][] = $validate;  
        $validate['check'] = "alpha";
        $validate['message'] = "Mag geen speciale karakters bevatten";
        $data['voornaam']['validate'][] = $validate;  

        $data['voornaam']['value'] = "SELF";

        $validate['check'] = "min1";
        $validate['message'] = "Dit veld mag niet leeg zijn";
        $data['achternaam']['validate'][] = $validate; 
        $validate['check'] = "alpha";
        $validate['message'] = "Mag geen speciale karakters bevatten";
        $data['achternaam']['validate'][] = $validate; 

        $data['achternaam']['value'] = "SELF";

        $validate['check'] = "email"; 
        $validate['message'] = "Vul een geldig emailadres in";
        $data['email']['validate'][] = $validate;  

        $data['email']['value'] = "SELF";

        $data['extra_info']['value'] = "SELF";

        $validate['check'] = "min1"; 
        $validate['message'] = "Dit veld mag niet leeg zijn";
        $data['school']['validate'][] = $validate;  

        $data['school']['value'] = "SELF";

        $validate['check'] = "min1"; 
        $validate['message'] = "Dit veld mag niet leeg zijn";
        $data['opleiding']['validate'][] = $validate;  

        $data['opleiding']['value'] = "SELF";

        $validate['check'] = "min1";
        $validate['message'] = "Dit veld mag niet leeg zijn";
        $data['leerjaar']['validate'][] = $validate;  
        $validate['check'] = "numeric";
        $validate['message'] = "Mag geen letters bevatten";
        $data['leerjaar']['validate'][] = $validate;  

        $data['leerjaar']['value'] = "SELF";

        $data['customer_id']['value'] = "SELF";


        $jsframework = new JSFramework();
        $functionname = $jsframework->createCall($data, '', false, array());
        print $jsframework->createLink($functionname, "Sollicitatie versturen", "btn btn-primary btn-sm");
      }
    


}