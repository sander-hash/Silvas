<?PHP 
class viewGeneralInformation extends viewMain
{
  
    function showStageBijSilvas($params){
        global $app;
        ob_start(); ?>
            <div class="container">
              <h1 class="">Stage Lopen Bij Silvas BV.</h1>
              <p class="mt-1 fw-bold">Heb jij interesse om Stage te lopen bij Silvas? Kijk hieronder even of hetgeen wat we bieden iets voor jouw is</p>
              <h2>Wat voor software Ontwikelt Silvas?</h2>
              <p>Silvas produceert voornamlijk software voor basis en voortgezet onderwijs.</p>
            </div>
        <?PHP 
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    function showOnzeHuisregels($params){
        global $app;
        ob_start(); ?>
        <div class="container">
        <h2 class="mb-1">Afspraken en huisregels Silvas</h2>
        <div class="accordion mt-3" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                Huishoudelijk regelement
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>This is the second item's accordion body.</strong> 
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                Afspraken stage silvas BV   
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>Afspraken Stage Silvas bv.</strong>         
                    (v1.1)
                    Veiligheid
                    <li>Codes en wachtwoorden blijven bij Silvas, gaan niet mee naar huis. Ook niet op USB, dvd etc.</li>
                    <li>Student gebruikt het programma 1Password of Keepass om wachtwoorden te bewaren. Silvas verzorgt hiervoor een account.</li>
                    <li>Geen persoonlijke apparaten (laptop, usb stick etc) aansluiten op computers of het netwerk van Silvas zonder overleg</li>
                    <li>Geen software installaties op apparatuur van Silvas zonder toestemming/overleg</li>
                    <li>Gebruik van Illegale software is niet toegestaan</li>
                    <br>
                    Werktijden
                    <br>
                    <li>Werkdag start om 9.00 tot 17.00</li>
                    <li>Pauze is van 12.00 tot 13.00</li>
                    <br>
                    Social media
                    <br>
                    <li>Social media, en persoonlijke email onder werktijd is toegestaan mits dit niet ten koste gaat van de kwaliteit van het werk.</li>
                    <li>Het is niet toegestaan om op Social media (zoals Twitter en Facebook) in een post te verwijzen naar (projecten en klanten van) Silvas.</li>
                    <br>
                    Stagevergoeding
                    <br>
                    <li>Studenten in het laatste jaar van de opleiding kunnen in aanmerking komen voor een stagevergoeding. Deze vergoeding bestaat uit 2 delen:</li>
                    <li>Vaste vergoeding van € 150,00 per maand</li>
                    <li>Variabele vergoeding van € 500,00 per maand per stage. Deze variabele vergoeding ontvangt de student als de student door Silvas een baan aangeboden krijgt en besluit om na de stageperiode minimaal 2 jaar te blijven werken bij Silvas.</li>
                    <li>Voorbeeld; de student loopt 5 maanden stage en komt daarna voor minimaal 2 jaar in loondienst; de student ontvangt €2500,-</li>
                    <li>Het is mogelijk om op projectbasis een vergoeding te ontvangen, maar dit gebeurd altijd in overleg.</li>
                    <li>De student ontvangt geen kilometervergoeding</li>
                    <br>
                    Communicatie</li>
                    <li>De student gebruikt het emailadres van Silvas om te communiceren ([...]@silvas.nl)</li>
                    <li>Alle documenten die de stagiair maakt, worden opgeslagen op een USB stick of de server/Github schijf die hij/zij te leen krijgt van Silvas</li>
                    <br>
                    Lunch / koffie / thee
                    <br>
                    <li>Er is koffie / thee / water etc. aanwezig</li>
                    <li>Neem zelf lunch mee (in de pauze is het mogelijk om even naar de winkel te lopen)</li>
                    <li>Op donderdag worden broodjes besteld (woensdag middag doorgeven welke je wilt bestellen)</li>
                    <br>
                    Overig
                    <li>Het is niet toegestaan om zonder overleg met Silvas betaalde diensten te verrichten voor klanten en relaties van Silvas. Ook niet nadat de stageperiode is verlopen.</li>
                    <li>De student draagt onvoorwaardelijk al het auteursrecht dat berust op de gemaakte werken (bijvoorbeeld programmeercode/websites/teksten/media) en in opdracht van Silvas is ontwikkeld over aan Silvas.</li>
                    <li>De stagiair krijgt een startopdracht aan het begin van de stage-periode</li>
                    <li>Alleen buiten kan gerookt worden</li>
                    <li>De stagiair is verantwoordelijk voor een opgeruimde werkplek</li>
                    <li>In het kantoor van Silvas hangen beveiligingscamera’s</li>
                    <li>De student levert een kopie identiteitsbewijs in bij aanvang van de stage</li>
                    <li>WC na gebruik controleren; is het nog klant-veilig?</li>
                    <li>Don’t touch de instellingen van het koffiezetapparaat</li>
              </div>
            </div>
          </div>
        </div>
    </div>
        <?PHP 
                  $data = ob_get_contents();
                  ob_end_clean();
                  return $data;
        
    }

    function showEvaluatie(){
        global $app;
        ob_start();
        $view = new viewUsers();
        $modelFWGroups = new modelFWGroups;
        $currentUserRole = $modelFWGroups->getRolesOfUser(0,true);
          if(in_array("stagiaires",$currentUserRole)){
             print $view->showUserTable();
          }elseif(in_array("begeleiders",$currentUserRole)){
            ?><div id="showEvaluatie"><?php
              print $view->showUserTableBegeleider();
              ?><br>
             </div>
          <?php
          }
          $data = ob_get_contents();
          ob_end_clean();
          return $data;
    }

}
  