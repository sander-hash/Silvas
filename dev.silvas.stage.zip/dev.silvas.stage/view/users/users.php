<?PHP 
class viewUsers extends viewMain
{
   
      function showUserTable(){
          $model = new modelUserInfo();
          $user_id = getUserId();
          $users =  $model->sortOnDate($user_id);

          $count = count($users);
        
          $tabel = new Table();
          ?><h2 class="mb-2">Er zijn <?php print $count?> evaluaties voor u</h2><?php
          $row = array(); 
          $row[] = "Naam evaluatie";
          $row[] = "Datum";
          $row[] = "Beoordeling";
          $row[] = "";
          $tabel -> addHead($row);
  
          foreach($users as $results)
          {
              // hier foreach je alle users die je op hebt gehaald door middel van de multiplekeys in een row
              $row = array();
              $row[] = $results->naam_evaluatie;
              $row[] = date("d-m-Y", strtotime($results->datum));
              $row[] = $results->beoordeling;
              $data['controller'] = '/evaluatie/showEvaluatie/'.$results->id;
              $data['evaluatie_id'] = $results->id;
              $jsframework = new JSFramework();
              $functionname = $jsframework->createCall($data, '', false, array());
              $button = $jsframework->createLink($functionname, "Bekijken ", "btn btn-primary btn-sm");
              
              $row[] = $button;
              $tabel->addRow($row);
          }
          return $tabel->html();
      }
      function showUserTableBegeleider(){
        global $app;
        ob_start();
        $keys['id'] = getUserId();
        $modelUsers = new modelFWUsers();

        $model = new modelUser();
        $users = $model->stagiair();
        $countStagiairHuidig = count($users);
        $afgerondeStagiairs = $model->stagiairAfgerond();
        $countStagiairAfgerond = count($afgerondeStagiairs);
        $class_files = new modelFWFiles();
        
        $modelCustomers = new modelFWCustomer();
            $customerId = getCustomerID();


        
        // $files = $class_files->getAll();

        
        ?><h2> Huidige stagiairs van <?php print $modelCustomers->getCustomerName($customerId); ?> (<?php  print $countStagiairHuidig; ?>)</h2><?php
        foreach($users as $results){
          $files = $class_files->getByMultipleKeys(array('user_id'=>$results->user_id));
          ?>  
          <div class="d-inline-flex p-2 bd-highlight shodow-lg mb-4">
          <div class="card mb-2 d-flex" style="width: 18rem;">
          <div class="card-body">
              <div class="p-2 bd-highlight">
              <?php
              if($files == array()){
                        ?><img src="https://dfge.de/wp-content/uploads/blank-profile-picture-973460_640.png" class="card-img" style=" height:175px"><?
                      }else{
                        foreach ($files as $file){
                        ?><img src="<?php print $class_files->getFileURL ($file->id) ?>" class="card-img" style=" height:175px"><?
                        }
                      }
              ?>
              <h5 class="card-title"><?php print $results->voornaam . " ". $results->achternaam ;?></h5>
              <p class="card-text"><?php print $results->extra_info?></p>
              <p class="card-text"><?php print $results->opleiding?></p>
              <p class="card-text"><?php print $results->email?></p>
               
        <br>
      <?php
          $data['controller'] = '/evaluatie/showEvaluatieStagiair/'.$results->user_id;
           $jsframework = new JSFramework();
           $functionname = $jsframework->createCall($data, '', false, array());
           $button = $jsframework->createLink($functionname, "Evaluaties inzien ", "btn btn-primary btn-sm mb-1");
                    
                   // button aanmaken voor gebruikers toe te voegen
           $data['controller'] = '/evaluatie/eindEvaluatieToevoegen/'.$results->user_id;
           $jsframework = new JSFramework();
           $functionname = $jsframework->createCall($data, '', false, array());
           $button .= $jsframework->createLink($functionname, "Stagiair afronden ", "btn btn-success btn-sm mb-1");

           $data['controller'] = '/profile/inzien/'.$results->user_id;
           $jsframework = new JSFramework();
           $functionname = $jsframework->createCall($data, '', false, array());
           $button .= $jsframework->createLink($functionname,'<i class="h5 bi bi-person-video2"></i>', "btn btn-primary btn-sm float-end","hideModal");

          print $button;

        
          ?>
          </div>
          </div>
          </div>
          </div>
          <?php

        }
        
        ?><h2> Afgeronde stagiairs van <?php print $modelCustomers->getCustomerName($customerId); ?> (<?php print $countStagiairAfgerond ?>)</h2><?php
        foreach($afgerondeStagiairs as $afgerondeStagiair){
          $files = $class_files->getByMultipleKeys(array('user_id'=>$afgerondeStagiair->user_id));
          ?>  
          <div class="d-inline-flex p-2 bd-highlight shodow-lg mb-4">
          <div class="card mb-2 d-flex" style="width: 18rem;">
          <div class="card-body">
              <div class="p-2 bd-highlight">
              <?php
              if($files == array()){
                ?><img src="https://dfge.de/wp-content/uploads/blank-profile-picture-973460_640.png" class="card-img" style=" height:175px"><?
              }else{
                foreach ($files as $file){
                ?><img src="<?php print $class_files->getFileURL ($file->id) ?>" class="card-img" style=" height:175px"><?
                }
              }
              ?>
              <h5 class="card-title"><?php print $afgerondeStagiair->voornaam . " ". $afgerondeStagiair->achternaam ;?></h5>
              <p class="card-text"><?php print $afgerondeStagiair->extra_info?></p>
              <p class="card-text"><?php print $afgerondeStagiair->opleiding?></p>
              <p class="card-text"><?php print $afgerondeStagiair->email?></p>
               
               
        <br>
      <?php
            $data['controller'] = '/evaluatie/showEvaluatieStagiair/'.$afgerondeStagiair->user_id;
            $jsframework = new JSFramework();
            $functionname = $jsframework->createCall($data, '', false, array());
            $button = $jsframework->createLink($functionname, "Evaluaties inzien ", "btn btn-primary btn-sm mb-1");
         

          $data['controller'] = '/evaluatie/verwijderen/'.$afgerondeStagiair->ID.'/'.$afgerondeStagiair->user_id;
          $jsframework = new JSFramework();
         
          $confirmbox['heading'] = "Stagiair verwijderen";
          $confirmbox['body'] = "Weet je zeker dat je <strong>".$afgerondeStagiair->voornaam."</strong> wilt verwijderen?";
          $confirmbox['cancel'] = "Annuleren";
          $confirmbox['continue'] = "Verwijderen";
          $functionname = $jsframework->createCall($data, '', false, $confirmbox,array());
          $button .= $jsframework->createLink($functionname, "Stagiair verwijderen ", "btn btn-danger btn-sm mb-1");

          $data['controller'] = '/profile/inzien/'.$afgerondeStagiair->user_id;
          $jsframework = new JSFramework();
          $functionname = $jsframework->createCall($data, '', false, array());
          $button .= $jsframework->createLink($functionname,'<i class="h5 bi bi-person-video2"></i>', "btn btn-primary btn-sm float-end","hideModal");

          print $button;
          ?>
          </div>
          </div>
          </div>
          </div>
          <?php

        }
            $data = ob_get_contents();
            ob_end_clean();
            return $data;
    }
  
      function showUserToevoegen(){
          ob_start();
          $model = new modelFWUsers();
          $users = $model->getAll();
          $modelGroups = new modelFWGroups(); ?>
            <form>
                <div class="myForm mb-3">
                  <label for="exampleInputEmail1" class="form-label">Naam</label>
                  <select class="form-select" id="user_id" type="text" name="user_id">
          <?php
          foreach ($users as $result){
            $user = get_userdata($result->wp_id);
            if($modelGroups->userHasRole($result->id, "stagiaires")){ ?>
                   <option value="<?php print $result->id ?>"><?php print $user->display_name;?></option>
               <?php 
                }
               }
              ?>     
                </select>
                <div class="form-group">
                <label for="voornaamLabel">Voornaam</label>
                <input type="text" class="form-control" id="voornaam" placeholder="Voornaam" required>
              </div>
              <div class="form-group">
                <label for="achternaamLabel">Achternaam</label>
                <input type="text" class="form-control" id="achternaam" placeholder="Achternaam" required>
              </div>
              <div class="form-group">
                <label for="telefoonLabel">Email</label>
                <input type="email" class="form-control" id="email" placeholder="email" required>
              </div>
              <div class="form-group">
                <label for="telefoon">Extra info</label>
                <input type="text" class="form-control" id="extra_info" placeholder="Extra info" required>
              </div>
              <div class="form-group">
                <label for="opleiding">opleiding + jaar</label>
                <input type="text" class="form-control" id="opleiding" placeholder="Opleiding" required>
              </div>
              <br>
          </form>
          <?php
          // hier haal de je alle data op uit de textboxes
          $data['controller'] = '/evaluatie/stagiairToevoegen';        
          $validate['check'] = "text"; 
          $validate['message'] = "Vul een voornaam in";
          $data['voornaam']['validate'][] = $validate; 
          $data['voornaam']['value'] = "SELF";
          $validate['check'] = "text"; 
          $validate['message'] = "Vul een achternaam in";
          $data['achternaam']['validate'][] = $validate; 
          $data['achternaam']['value'] = "SELF";
          $validate['check'] = "email"; 
          $validate['message'] = "Vul een geldig emailadres in";
          $data['email']['validate'][] = $validate;  
          $data['email']['value'] = "SELF";
          $data['extra_info']['value'] = "SELF";
          $data['avatar']['value'] = "SELF";
          $data['opleiding']['value'] = "SELF";
          $data['user_id']['value'] = "SELF";


          
          // hier maak je een button aan en stuur je de data die je opgehaald in de $data variable mee
          $jsframework = new JSFramework();
          $functionname = $jsframework->createCall($data, '', false, array());
          print $jsframework->createLink($functionname, "Stagiair toevoegen", "btn btn-primary btn-sm","hideModal");

          $value = ob_get_contents();
          ob_end_clean();
          return $value;
      }

      function stagiairInzien($params){
        ob_start();
        $id = getUserId();
        $keys['user_id'] = $params['user_id'];
        
        $model = new modelUser();
        $users = $model->getByMultipleKeys($keys);
        foreach($users as $user){
        ?>
        <form>
                <div class="form-group">
                <label for="voornaamLabel">Voornaam</label>
                <input type="text" value="<?php echo $user->voornaam;?>" class="form-control" id="voornaam" placeholder="Voornaam" required readonly>
              </div>
              <div class="form-group">
                <label for="achternaamLabel">Achternaam</label>
                <input type="text" value="<?php echo $user->achternaam;?>" class="form-control" id="achternaam" placeholder="Achternaam" required readonly>
              </div>
              <div class="form-group">
                <label for="telefoonLabel">Email</label>
                <input type="email" value="<?php echo $user->email;?>" class="form-control" id="email" placeholder="email" required readonly>
              </div>
              <div class="form-group">
                <label for="telefoon">Extra info</label>
                <input type="text" value="<?php echo $user->extra_info;?>" class="form-control" id="extra_info" placeholder="Extra info" required readonly>
              </div>
          
              <div class="form-group">
                <label for="opleiding">opleiding + jaar</label>
                <input type="text" value="<?php echo $user->opleiding;?>" class="form-control" id="opleiding" placeholder="Opleiding" required readonly>
              </div>
              <div class="form-group">
                <label for="opleiding">Noodnummer</label>
                <input type="text" value="<?php echo $user->noodnummer;?>" class="form-control" id="noodnummer" placeholder="noodnummer" required readonly>
              </div>
              <br>
          </form>
          <?php
        
        }
        $value = ob_get_contents();
        ob_end_clean();
        return $value;


      }

      function profielBewerken(){
        ob_start();
        $id = getUserId();
        $keys['user_id'] = $id;
        
        $model = new modelUser();
        $users = $model->getByMultipleKeys($keys);
        $class_files = new modelFWFiles();
        foreach($users as $user){
        ?>
      


        <div class="row">
        <div style="width:50%;">
        <form>
                <div class="form-group col">
                <label for="voornaamLabel">Voornaam veranderen</label>
                <input type="text" value="<?php echo $user->voornaam;?>" class="form-control" id="voornaam" placeholder="Voornaam" required>
              </div>
              <div class="form-group col">
                <label for="achternaamLabel">Achternaam veranderen</label>
                <input type="text" value="<?php echo $user->achternaam;?>" class="form-control" id="achternaam" placeholder="Achternaam" required>
              </div>
              <div class="form-group col">
                <label for="telefoonLabel">Email veranderen</label>
                <input type="email" value="<?php echo $user->email;?>" class="form-control" id="email" placeholder="email" required>
              </div>
              <div class="form-group col">
                <label for="telefoon">Extra info toevoegen</label>
                <input type="text" value="<?php echo $user->extra_info;?>" class="form-control" id="extra_info" placeholder="Extra info" required>
              </div>
          
              <div class="form-group col">
                <label for="opleiding">opleiding + jaar veranderen</label>
                <input type="text" value="<?php echo $user->opleiding;?>" class="form-control" id="opleiding" placeholder="Opleiding" required>
              </div>
              <div class="form-group col">
                <label for="opleiding">Noodnummer toevoegen</label>
                <input type="text" value="<?php echo $user->noodnummer;?>" class="form-control" id="noodnummer" placeholder="noodnummer" required>
              </div>
          </form>
        
 
        
        
          <?php
           
          $data['controller'] = '/profile/profielBewerken/'.$user->ID;
          $data['voornaam']['value'] = "SELF";
          $data['achternaam']['value'] = "SELF";
          $data['email']['value'] = "SELF";
          $data['extra_info']['value'] = "SELF";
          $data['opleiding']['value'] = "SELF";
          $data['noodnummer']['value'] = "SELF";
          $jsframework = new JSFramework();
          $functionname = $jsframework->createCall($data, '', false, array());
          print $jsframework->createLink($functionname, "Profiel bewerken", "btn btn-primary btn-sm mt-2 mb-2","refreshPage");
          ?><br> Wachtwoord veranderen: <?php
          $data['controller'] = '/users/showchangepassword';
          $jsframework = new JSFramework();
          $functionname = $jsframework->createCall($data, '', false, array());
          print $jsframework->createLink($functionname, "<i class=\"bi bi-person-fill\"></i>", 'btn btn-sm btn-secondary', '');
          ?></div><?php
          ?><script>
            function refreshPage() {
              location.reload()
          }
          </script>  
                    <div class="row" style="width:50%;">
                    <div class="form-group col-auto">
                    <label for="avatar">Huidige profielfoto:</label>
                  </div>
              <?php $files = $class_files->getByMultipleKeys(array('user_id'=>$id));
               foreach ($files as $file){
                 ?>
              <img class="rounded-circle" src="<?php print $class_files->getFileURL ($file->id) ?>" style="height:300px; width:300px;"><?php
                $file_id = $file->id;
               }
               ?>
               
              
              <form action="/evaluatie/avatarUpload" method="post" enctype="multipart/form-data">
                <input class="mt-2 form-control " type="file" required name="files[]" multiple accept="image/*"><BR>
                <input class="mt-2 form-control " type="submit" required value="Avatar uploaden">
                </form>
                  
              </div>
              </div>
                <br>
             
              <?php
        }
        
          $value = ob_get_contents();
          ob_end_clean();
          return $value;
      }





}