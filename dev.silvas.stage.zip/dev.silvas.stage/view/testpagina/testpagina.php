<?php

class viewTestpagina extends viewMain
{
    

    function showTestpagina($params)
    {
        global $app;
        ob_start();
        print ("<h1>test pagina</h1> <br>");
        print $this->printTable();
        print $this->printForm();
        $value = ob_get_contents();
        ob_end_clean();
        return $value;
    }

    function printForm()
    {
        $data['controller'] = '/testpagina/toevoegen';
        $jsframework = new JSFramework();

        $functionname = $jsframework->createCall($data, '', false, array());
        print $jsframework->createLink($functionname, "Toevoegen", "btn btn-primary btn-sm");



    }
    function printTable()
    {
        ob_start();
        $model = new modelInvoer();
        $users = $model->getAll();
        $tabel = new Table();
        
        $row = array();
        $row[] = "id";
        $row[] = "user";
        $row[] = "";
        $tabel -> addHead($row);
        foreach($users as $results)
        {
            $row = array();
            $row[] = $results->id;
            $row[] = $results->user;
            
            $data['controller'] = '/evaluatie/verwijderen/'.$results->id;        
            $jsframework = new JSFramework();

            // stel de confirmbox in
            $confirmbox['heading'] = "User verwijderen";
            $confirmbox['body'] = "Weet je zeker dat je de user ".$results->user." wilt verwijderen?";
            $confirmbox['cancel'] = "Annuleren";
            $confirmbox['continue'] = "Verwijderen";
    
            $functionname = $jsframework->createCall($data, '', false, $confirmbox);
            $row[] = $jsframework->createLink($functionname, "Delete", "btn btn-danger btn-sm");


    
            $tabel->addRow($row);




        }
        return $tabel->html();
        
        
    
        
        
        $data = ob_get_contents();
    ob_end_clean();
    return $data;

    }
    function showUserToevoegen(){
        ob_start();
        ?>
        <form>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Usernaam</label>
    <input type="name" class="form-control" id="name" aria-describedby="name">
    <div id="name" class="form-text">Vul hier de gewenste user in.</div>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Verzenden</button>
    </form>

        <?php
        $data = ob_get_contents();
        ob_end_clean();
        return $data;
    }

}


