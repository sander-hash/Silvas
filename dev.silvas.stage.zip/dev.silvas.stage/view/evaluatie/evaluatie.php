<?PHP 
class viewEvaluatie extends viewMain
{

    function inzienEvaluaties($params, $user_id){
      global $app;
      ob_start();
      $model = new modelUserInfo();
      print $this->showEvaluatiesTable($user_id);
      $data = ob_get_contents();
      ob_end_clean();
      return $data;
    }

    function showEvaluatiesTable($user_id){


      $model = new modelUserInfo();
      $modelUser = new modelUser();
      $keys["user_id"] = $user_id;
      $user = $modelUser->getByMultipleKeys($keys);
      $users = $model->sortOnDate($user_id);
      $tabel = new Table();
      
      $gebruikers = $modelUser->getByMultipleKeys($keys);
      foreach ($gebruikers as $gebruiker){
        $stageAfgerond = $gebruiker->stageAfgerond;
      }
    
      foreach ($user as $stagiair){
      ?>
      <h2 class="mb-2">Evaluaties van <?php print $stagiair->voornaam .  " " . $stagiair->achternaam?></h2><?php
      
      $data['controller'] = '/evaluatie/showEvaluatieToevoegen/'.$stagiair->user_id; 
      }
      $jsframework = new JSFramework();
      $fname = $jsframework->createCall($data, '', false, array());
      $btn = $jsframework->createLink($fname, "Evaluatie toevoegen ", "btn btn-primary btn-sm");
      if($stageAfgerond == 0){
      print $btn;
      }
      $row = array();
      $row[] = "Naam evaluatie";
      $row[] = "Datum";
      $row[] = "Beoordeling";
      $row[] = "";
      $row[] = "";
      $row[] = "";
      $tabel -> addHead($row);

      foreach($users as $results)
      {
          // hier foreach je alle users die je op hebt gehaald door middel van de multiplekeys in een row
          $row = array();
          $row[] = $results->naam_evaluatie;
          $row[] = date("d-m-Y", strtotime($results->datum));
          $row[] = $results->beoordeling;
          $data['controller'] = '/evaluatie/opmerkingToevoegenModal/'.$results->id.'/'.$user_id;
          $data['evaluatie_id'] = $results->id;
          $jsframework = new JSFramework();
          $functionname = $jsframework->createCall($data, '', false, array());
          $button = $jsframework->createLink($functionname, "Bekijken ", "btn btn-primary btn-sm");


          $data['controller'] = '/evaluatie/evaluatieVerwijderen/'.$results->id.'/'.$user_id;
          $jsframework = new JSFramework();
          $confirmbox['heading'] = "Evaluatie verwijderen";
          $confirmbox['body'] = "Weet je zeker dat je deze evaluatie wilt verwijderen ";
          $confirmbox['cancel'] = "Annuleren";
          $confirmbox['continue'] = "Verwijderen";
          $functionname = $jsframework->createCall($data, '', false,  $confirmbox, array());
          if($stageAfgerond == 0){
          
          $button .= $jsframework->createLink($functionname, "Evaluatie verwijderen ", "btn btn-danger btn-sm ms-1");
          }
          
          $row[] = $button;
          
          $tabel->addRow($row);

      }
      return $tabel->html();
  }

    function showModalOpmerkingToevoegen($params){
      ob_start();
      $begeleiderKey['id'] = getUserId();
      $modelBegeleiders = new modelFWUsers();
      $begeleiders = $modelBegeleiders->getByMultipleKeys($begeleiderKey);
      foreach ($begeleiders as $begeleider){
        $user = get_userdata($begeleider->wp_id);
        $name = $user->display_name;
        $name->user_nicename;        
      }



      $user_id = $params['user_id'];
      $userKey["user_id"] = $user_id;
      $id = $params['id'];
      $keys["id"] = $id;
      $key['evaluatie_id'] = $id; 
      $model = new modelUserInfo();
      $modelOpmerkingen = new modelOpmerkingen();
      $opmerkingen = $modelOpmerkingen->getByMultipleKeys($key);
      $evaluaties = $model->getByMultipleKeys($keys);
      $countOpmerkingen = count($opmerkingen);
      $modelGroups = new modelFWGroups();

      $modelUser = new modelUser();
      $gebruikers = $modelUser->getByMultipleKeys($userKey);
      foreach ($gebruikers as $gebruiker){
        $stageAfgerond = $gebruiker->stageAfgerond;
      }
      
      
      ?>
        <form>
        <?php foreach ($evaluaties as $result){
          $user_id = $result->user_id;
          ?>
          <label for="exampleFormControlTextarea1" class="form-label">Evaluatie van: <?php print date("d-m-Y", strtotime($result->datum));?></label>
          
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Evaluatie:</label>
          
          <textarea class="form-control" id="evaluatie" readonly name="evaluatie" rows="3"><?php print $result->evaluatie;?></textarea>
          <?php } ?>
          
        </div>
        <?php if($stageAfgerond == 0){?>
        <label for="exampleFormControlTextarea1 mb-2" class="form-label">Opmerking:</label>
        <textarea class="form-control mb-2" id="opmerking" name="opmerking" rows="3"></textarea>
        <?php } ?>
        <?php
        $data['controller'] = '/evaluatie/opmerkingToevoegen/'.$user_id; 
        $data['evaluatie_id'] = $id;
        $data['opmerking']['value'] = "SELF";
        $data['naam_begeleider'] = $name;
      $jsframework = new JSFramework();
      $currentUserRole = $modelGroups->getRolesOfUser(0,true);
      $functionname = $jsframework->createCall($data, '', false, array());
      if($stageAfgerond == 0){
      print $jsframework->createLink($functionname, "Opmerking toevoegen", "btn btn-primary btn-sm mb-2","hideModal");
      }
      
      ?>
      <br>
        <label for="exampleFormControlTextarea1" class="form-label">Momenteel <?php print $countOpmerkingen ?> opmerkingen gegeven</label>
        <?php foreach ($opmerkingen as $opmerking){?>
                     <br><label for="exampleFormControlTextarea1" class="form-label">Door: <?php print $opmerking->naam?></label>
                      <textarea class="form-control mb-2" id="evaluatie" readonly name="evaluatie" rows="3"><?php print $opmerking->opmerking;?></textarea>
                      <?php 
                      $data['controller'] = '/evaluatie/opmerkingVerwijderen/'.$opmerking->id.'/'.$user_id; 
                       $functionname = $jsframework->createCall($data, '', false, array());
                       if(in_array("begeleiders",$currentUserRole)){
                       if($stageAfgerond == 0){
                       print $jsframework->createLink($functionname, "Opmerking Verwijderen", "btn btn-danger btn-sm mb-2","hideModal");
                       }
                      }
                    } 
                    ?>
                  
  </form>
      <?php

      $value = ob_get_contents();
      ob_end_clean();
      return $value;
    }
    function showEvaluatieToevoegen($params){
        ob_start();
        $model = new modelUser();
        $id = $params['user_id'];
        $key['user_id'] = $params['user_id'];
        $users = $model->getByMultipleKeys($key);
        $modelGroups = new modelFWGroups();
        ?>
        <?php foreach ($users as $user){
          $voornaam = $user->voornaam;
          $achternaam = $user->achternaam;
          $email = $user->email;
        }
        ?>
          <form>
          <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Naam evaluatie</label>
            <textarea class="form-control" id="naam_evaluatie" name="naam_evaluatie" rows="1"></textarea>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Evaluatie</label>
            <textarea class="form-control" id="evaluatie" name="evaluatie" rows="3"></textarea>
          </div>
          <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Beoordeling</label>
          <select class="form-select" id="beoordeling" type="text" name="beoordeling">
            <option value="O">O</option>
            <option value="V">V</option>
            <option value="G">G</option>
            <option value="U">U</option>
        </select>
        </div>
            <input class="form-control" type="date" id="date" name="trip-start"></input>
          <br>
    </form>
        <?php
        $data['controller'] = '/evaluatie/evaluatieToevoegen/'.$id; 
        $data['user_id'] = $id;
        $data['naam_eva'] = $voornaam;
        $data['achternaam'] = $achternaam;
        $data['email'] = $email;
        $data['naam_evaluatie']['value'] = "SELF";
        $data['date']['value'] = "SELF";
        $data['evaluatie']['value'] = "SELF";
        $data['beoordeling']['value'] = "SELF";
        

        $jsframework = new JSFramework();
        $currentUserRole = $modelGroups->getRolesOfUser(0,true);
        if(in_array("begeleiders",$currentUserRole)){
        $functionname = $jsframework->createCall($data, '', false, array());
        print $jsframework->createLink($functionname, "Evaluatie toevoegen", "btn btn-primary btn-sm","hideModal");
        }
        $value = ob_get_contents();
        ob_end_clean();
        return $value;
    }

    function showEvaluatieStagiair($id, $evaluatie_id){
        ob_start();
        $modelOpmerkingen = new modelOpmerkingen();
        $key["evaluatie_id"] = $id;
        $opmerkingen = $modelOpmerkingen->getByMultipleKeys($key);
        $countOpmerkingen = count($opmerkingen);
        $model = new modelUserInfo();
        $modelGroups = new modelFWGroups();
        $keys["id"] = $id;
        $users = $model->getByMultipleKeys($keys);
            foreach ($users as $result){ ?>
            <label for="exampleFormControlTextarea1" class="form-label">Evaluatie van: <?php print $result->datum?></label>
              <div class="mb">
              <label for="exampleFormControlTextarea1" class="form-label">Evaluatie</label>
              <textarea class="form-control" id="evaluatie" readonly name="evaluatie" rows="3"><?php print $result->evaluatie;?></textarea>
            <?php } ?>
            <br>
            <label for="exampleFormControlTextarea1" class="form-label">Momenteel <?php print $countOpmerkingen ?> opmerkingen gekregen</label>
            <br>
        <?php
        foreach ($opmerkingen as $opmerking){ ?>          
              <label for="exampleFormControlTextarea1" class="form-label">Naam: <?php print $opmerking->naam?></label>
              <textarea class="form-control" id="evaluatie" readonly name="evaluatie" rows="3"><?php print $opmerking->opmerking;?></textarea>
        <?php } 
        $value = ob_get_contents();
        ob_end_clean();
        return $value;
    }
    
    function showEindEvaluatie($params){
      ob_start();
      $model = new modelUser();
      $id = $params['user_id'];
      $key['user_id'] = $params['user_id'];
      $users = $model->getByMultipleKeys($key);
      $modelGroups = new modelFWGroups();
      ?>
      <?php foreach ($users as $user){
        $voornaam = $user->voornaam;
        $achternaam = $user->achternaam;
        $id_user = $user->ID;
        $email = $user->email;
      }
      
      ?>
      
        <form>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Evaluatie</label>
          <textarea class="form-control" id="evaluatie" name="evaluatie" rows="3"></textarea>
        </div>
        <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Beoordeling</label>
        <select class="form-select" id="beoordeling" type="text" name="beoordeling">
          <option value="O">O</option>
          <option value="V">V</option>
          <option value="G">G</option>
          <option value="U">U</option>
      </select>
      </div>
          <input class="form-control" type="date" id="date" name="trip-start"></input>
        <br>
  </form>
      
      <?php
      foreach ($users as $result){
      $data['controller'] = '/evaluatie/stagiairAfronden/'.$result->ID.'/'.$result->user_id; 
      $data['email'] = $email;
      $data['voornaam'] = $voornaam;
      $data['achternaam'] = $achternaam;
      $data['naam_evaluatie'] = "Eindevaluatie";
      $data['date']['value'] = "SELF";
      $data['evaluatie']['value'] = "SELF";
      $data['beoordeling']['value'] = "SELF";
      

      
      }
      $currentUserRole = $modelGroups->getRolesOfUser(0,true);
      if(in_array("begeleiders",$currentUserRole)){
      $jsframework = new JSFramework();
      $functionname = $jsframework->createCall($data, '', false, array());
      print $jsframework->createLink($functionname, "Eindevaluatie toevoegen", "btn btn-primary btn-sm","hideModal");
      
      }
      $value = ob_get_contents();
      ob_end_clean();
      return $value;
    }
    

}