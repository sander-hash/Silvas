<?php
/**
 * Plugin Name: Stage portal
 * Plugin URI: https://silvas.dev
 * Description: Silvas App that runs on Framework
 * Author: Silvas development
 * Author URI: http://www.silvas.nl
 * Version: 1.0.0
 * Plugin Slug: stage-portal
*/


include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

add_action( 'init', 'silvas_app', 100 );
function silvas_app()
{    
    if (! is_plugin_active('framework/framework.php'))
    {        
        print "Framework is niet geladen";
        return;
    }
    else
    {

            
        // $US = new modelFMUsers();
        // $US->insertUserSymLink(get_current_user_id(), 1 );

        // set directories to include
        $app_dirs = array('view','controller','model','template','controls','global','routes');
        $scriptloader = new scriptLoader();

        //! pas hieronder de juiste naam van de plugin aan!
        $scriptloader->load($app_dirs,'dev.silvas.stage');
    }
}

