<?php

class controllerGeneralInfo extends DefaultController
{

    function __construct()
    {
        
    }

    function actionStageBijSilvas($params){
        global $app;
        $view = new viewGeneralInformation();              
        $app->content = $view->showStageBijSilvas($params);
    }

    function showHuisregels($params){
        global $app;
        $view = new viewGeneralInformation();              
        $app->content = $view->showOnzeHuisregels($params);
    }

  
}

