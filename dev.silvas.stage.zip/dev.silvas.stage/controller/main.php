<?PHP

class App_5 extends App
{

    function __construct()
    {
        parent::__construct(); 

        $permission = $this->glob->helperFWPermissions;
        $permission->setPermission("add_user_to_role", "allusers");
        $permission->setPermission("create_new_role", "allusers");
        // fwMail contains the framework smtp mailer settings
        $fwMail = new helperFWMail();
        $fwMail->addProfile("default", "dev@silvas.nl", "Tur32833", "Evaluatie app");


        
        $this->use_messenger = true;

        $this->template = new templateMain();
 

        $this->template_settings['login_logo'] = "https://stage.silvas.dev/wp-content/uploads/sites/5/2022/01/logo_high.png";
        $this->template_settings['login_background'] = "https://stage.silvas.dev/wp-content/uploads/sites/5/2022/01/silvas_inlog-scaled.jpg";
        $this->app_title = "Silvas stage portaal";
        // stel de map in met de verborgen bestanden
        $this->file_path_private = "/srv/users/dev-01/apps/dev-01/private/app_5";

        // stel de map in met de publiek toegankelijk bestanden
        $this->file_path_public = "/srv/users/dev-01/apps/dev-01/public/download/app_5";
        
    }
    protected final function getVeritas()
    {
        return "STAGE";
    }
}
