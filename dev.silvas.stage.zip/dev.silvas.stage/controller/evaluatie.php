<?php
class controllerEvaluatie extends DefaultController
{
    function showEvaluatie(){
        global $app;
        $view = new viewGeneralInformation();
        $app->content = $view->showEvaluatie();
    }

    function addEvaluatie($params)
    {
        global $app;
        $user_id = $params['id'];
        $view = new viewEvaluatie();
        $res = new Response();
        $model = new modelUserInfo();

        $mailTemplate = new mail();
        $mail = $mailTemplate->mailTemplate();
        
        $naam = $app->post['naam_eva'];
        $achternaam = $app->post['achternaam'];
        $email = $app->post['email'];


        // hier haal je al de data op en stuur je het mee naar de database
        $ar = array();
        $ar ['user_id'] = $app->post['user_id'];
        $ar ['naam_evaluatie'] = $app->post['naam_eva'];
        $ar ['datum'] = $app->post['date'];
        $ar ['evaluatie'] = $app->post['evaluatie'];
        $ar ['beoordeling'] = $app->post['beoordeling'];
        
        $validate ['naam_evaluatie'] = $app->post['naam_evaluatie'];
        foreach($validate as $jsonvalidatekey =>$jsonvalidatevalue ){
            if($jsonvalidatevalue == ""){

                $ar ['user_id'] = $app->post['user_id'];
                $ar ['naam_evaluatie'] = "Evaluatie van " . $app->post['naam_eva'] . " " .  $achternaam;
                $ar ['datum'] = $app->post['date'];
                $ar ['evaluatie'] = $app->post['evaluatie'];
                $ar ['beoordeling'] = $app->post['beoordeling'];
                $model->addRecord($ar);
                $to = $email;
                $message = $mail;
                $headers = "Content-Type: text/html; charset=UTF-8\r\n";
                $headers .= "Reply-To: dev@silvas.nl <dev@silvas.nl>\r\n";
                $headers .= "Return-Path: dev@silvas.nl <dev@silvas.nl>\r\n";
                $headers .= "From: Evaluatie app Silvas <dev@silvas.nl>\r\n"; 
                $subject = "Hey ".$naam." ".$achternaam." er is een nieuwe evaluatie toegevoegd!";
                fw_mail($to, $subject, $message, $headers,  $attachments = array());
                $page = array();
                $page['#showEvaluatie'] =  $view->inzienEvaluaties($params, $user_id);//hier kan je ook checken of de juiste variables worden meegegeven
                toast($title="Evaluatie toegevoegd ", $content="de evaluatie is toegevoegd", $time=0);
                $res->addVar('page', $page);
                $res->send();


                $invalid = 1;
            }
            if($invalid == 0){
                
                $ar ['user_id'] = $app->post['user_id'];
                $ar ['naam_evaluatie'] = $app->post['naam_evaluatie'];
                $ar ['datum'] = $app->post['date'];
                $ar ['evaluatie'] = $app->post['evaluatie'];
                $ar ['beoordeling'] = $app->post['beoordeling'];
                $model->addRecord($ar);
                $to = $email;
                $message = $mail;
                $headers = "Content-Type: text/html; charset=UTF-8\r\n";
                $headers .= "Reply-To: dev@silvas.nl <dev@silvas.nl>\r\n";
                $headers .= "Return-Path: dev@silvas.nl <dev@silvas.nl>\r\n";
                $headers .= "From: Evaluatie app Silvas <dev@silvas.nl>\r\n"; 
                $subject = "Hey ".$naam." ".$achternaam." er is een nieuwe evaluatie toegevoegd!";
                fw_mail($to, $subject, $message, $headers,  $attachments = array());
                $page = array();
                $page['#showEvaluatie'] = $view->inzienEvaluaties($params, $user_id);//hier kan je ook checken of de juiste variables worden meegegeven
                toast($title="Evaluatie toegevoegd ", $content="de evaluatie is toegevoegd", $time=0);
                $res->addVar('page', $page);
                $res->send();

                }
  
        }

    }
    function showModalEvaluatie($params)
    {
        global $app;
        $view = new viewEvaluatie();
        $res = new Response();
        $model = new modelUserInfo();
        $id = $params['id'];
        $evaluatie_id = $id;
        $res->addModal("Evaluatie", $view->showModalOpmerkingToevoegen($params));
        $res->send();
    }

    function showModalOpmerkingToevoegen($params){

        global $app;
        
        $view = new viewEvaluatie();
        $res = new Response();
        $res->addModal("Opmerking toevoegen", $view->showModalOpmerkingToevoegen($params));

        $res->send();
    }

    function opmerkingToevoegen($params){
        global $app;
        $user_id = $params['user_id'];
        $view = new viewUsers();
        $viewEvaluatie = new viewEvaluatie();
        $res = new Response();
        $model = new modelOpmerkingen();
        // hier haal je al de data op en stuur je het mee naar de database
        $ar = array();
        $ar ['evaluatie_id'] = $app->post['evaluatie_id'];
        $ar ['opmerking'] = $app->post['opmerking'];
        $ar ['naam'] = $app->post['naam_begeleider'];
        $model->addRecord($ar);

        $page = array();
        $page['#showEvaluatie'] =  $viewEvaluatie->inzienEvaluaties($params, $user_id);//hier kan je ook checken of de juiste variables worden meegegeven
        toast($title="Opmerking toegevoegd ", $content="De opmerking is toegevoegd", $time=0);
        $res->addVar('page', $page);
        $res->send();
    }

    function showEvaluatieStagiair($params){
        global $app;
        $view = new viewEvaluatie();
        $res = new Response();
        $user_id = $params['user_id'];
        $page = array();
        $page['#showEvaluatie'] =  $view->inzienEvaluaties($params, $user_id);//hier kan je ook checken of de juiste variables worden meegegeven
        $res->addVar('page', $page);
        $res->send();
    }
    function inzienEvaluaties($params, $user_id){
        global $app;
        ob_start();
        $model = new modelUserInfo();
        print $this->showEvaluatiesTable($user_id);
        $data = ob_get_contents();
        ob_end_clean();
        return $data;
      }

    function showModalEvaluatieToevoegen($params)
    {
        global $app;
        
        $view = new viewEvaluatie();
        $res = new Response();
        $res->addModal("Evaluatie toevoegen", $view->showEvaluatieToevoegen($params));

        $res->send();
    }
    function showEindEvaluatie($params)
    {
        global $app;
        
        $view = new viewEvaluatie();
        $res = new Response();
        $res->addModal("Eind evaluatie toevoegen", $view->showEindEvaluatie($params));

        $res->send();
    }
    function verwijderEvaluatie($params)
    {
        global $app;
        $view = new viewEvaluatie();
        $res = new Response();
        $user_id = $params['user_id'];
        //hier delete je de user aan de hand van welke record is aangeklikt
        $record_id = $params['id'];
        $model = new modelUserInfo();
        $model->deleteRecord($record_id);
        $modelOpmerkingen = new modelOpmerkingen();
        $modelOpmerkingen->deleteOpmerkingen($record_id);

        $page = array();
        $page['#showEvaluatie'] =  $view->inzienEvaluaties($params, $user_id);//hier kan je ook checken of de juiste variables worden meegegeven
        toast($title="Evaluatie verwijderd ", $content="De evaluatie is verwijderd", $time=0);
        $res->addVar('page', $page);
        $res->send();

    }
    function verwijderOpmerking($params)
    {
        global $app;
        $view = new viewEvaluatie();
        $res = new Response();
        $user_id = $params['user_id'];
        //hier delete je de user aan de hand van welke record is aangeklikt
        $record_id = $params['id'];
        $model = new modelOpmerkingen();
        $model->deleteRecord($record_id);
        
        
        $page = array();
        $page['#showEvaluatie'] =  $view->inzienEvaluaties($params, $user_id);//hier kan je ook checken of de juiste variables worden meegegeven
        toast($title="Opmerking verwijderd ", $content="De opmerking is verwijderd", $time=0);
        $res->addVar('page', $page);
        $res->send();

    }
    
    
}