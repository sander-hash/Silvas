<?php 
class controllerUsers extends DefaultController{

    function showModalToevoegen()
    {
        global $app;
        $view = new viewUsers();
        $res = new Response();
        $res->addModal("User toevoegen", $view->showUserToevoegen($params));
        $res->send();
    }

    function inzienProfielStagiair($params){
        global $app;
        $view = new viewUsers();
        $res = new Response();
        $res->addModal("Stagiair profiel", $view->stagiairInzien($params));
        $res->send();
    }

    function profiel(){
        global $app;
        $view = new viewUsers();
        $res = new Response();
        $res->addModal("Profiel bewerken",  $view->profielBewerken());
        $res->send();
    }
    function addStagiair($params){
        $view = new viewSolliciteren();
        $res = new Response();
        $model = new modelUser();
        $modelStagiair = new modelSolliciteren();
        $id = $params['id'];
        $keys['id'] = $id;
        
        // hier haal je al de data op en stuur je het mee naar de database
        $stagiairs = $modelStagiair->getByMultipleKeys($keys);
        foreach($stagiairs as $stagiair)
        {
            $voornaam = $stagiair->voornaam;
            $achternaam = $stagiair->achternaam;
            $email = $stagiair->emailadres;
            $extra_info = $stagiair->opmerking;
            $opleiding = $stagiair->opleiding;
            $customer_id = $stagiair->customer_id;
        }

        $silvas = new modelFWUsers();
        
        $bytes = openssl_random_pseudo_bytes(4);
        
        $password = bin2hex($bytes);

        $userExists = $silvas->userExists($email);
        
        if($userExists == 0){
        // $password = "pass";
        // createuser geeft het id terug van wp
        $wp_id = $silvas->createUser($email, $password, false);
        // haal hier het id op van de symlink
        $silvas_id = $silvas->insertUserSymLink($wp_id, 0, 1);

        
        $groups = new modelFWGroups();
                
                $stagiair = $groups->getGroupByName("stagiaires");
                $groups->addUserToGroup($silvas_id,$stagiair->id);

        $to = $email;
        $subject = "Account aangemaakt!";
        $message ="inlognaam:".$email." wachtwoord:".$password;
        $headers = "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Reply-To: dev@silvas.nl <dev@silvas.nl>\r\n";
        $headers .= "Return-Path: dev@silvas.nl <dev@silvas.nl>\r\n";
        $headers .= "From: Evaluatie app Silvas <dev@silvas.nl>\r\n"; 
        fw_mail($to, $subject, $message, $headers,  $attachments = array());

        $ar = array();

        $ar ['voornaam'] = $voornaam;
        $ar ['achternaam'] = $achternaam;
        $ar ['email'] = $email;
        $ar ['extra_info'] = $extra_info;
        $ar ['opleiding'] = $opleiding;
        $ar ['user_id'] = $silvas_id;
        $ar ['stageAfgerond'] = 0;
        $ar ['customer_id'] = $customer_id;
        $model->addRecord($ar);
        $modelStagiair->deleteRecord($id);
        $page = array();
        $page['#solliciteren'] = $view->showSolliciterenBijSilvas($params);//hier kan je ook checken of de juiste variables worden meegegeven
        
        // $to = $ar['email'];
        // $subject = "U bent toegevoegd aan het stagiairesportaal";
        // $message = "Hey " .  $ar ['voornaam'] . " " . $ar['achternaam'] . " Je bent toegevoegd aan het studentenportaal.";
        // fw_mail($to, $subject, $message, $headers = '',  $attachments = array());

        toast($title="Stagiair toegevoegd ", $content="User: " . $ar['voornaam'] . " " . $ar['achternaam'] . " is toegevoegd", $time=0);
        $res->addVar('page', $page);
        $res->send();
        }else{
            $silvas_id = $silvas->insertUserSymLink($userExists, 0, 1);
            $groups = new modelFWGroups();
                
            $stagiair = $groups->getGroupByName("stagiaires");
            $groups->addUserToGroup($silvas_id,$stagiair->id);
            $ar = array();

            $ar ['voornaam'] = $voornaam;
            $ar ['achternaam'] = $achternaam;
            $ar ['email'] = $email;
            $ar ['extra_info'] = $extra_info;
            $ar ['opleiding'] = $opleiding;
            $ar ['user_id'] = $silvas_id;
            $ar ['stageAfgerond'] = 0;
            $ar ['customer_id'] = $customer_id;
            $model->addRecord($ar);
            $modelStagiair->deleteRecord($id);
            $page = array();
            $page['#solliciteren'] = $view->showSolliciterenBijSilvas($params);//hier kan je ook checken of de juiste variables worden meegegeven
            
            // $to = $ar['email'];
            // $subject = "U bent toegevoegd aan het stagiairesportaal";
            // $message = "Hey " .  $ar ['voornaam'] . " " . $ar['achternaam'] . " Je bent toegevoegd aan het studentenportaal.";
            // fw_mail($to, $subject, $message, $headers = '',  $attachments = array());
    
            toast($title="Stagiair toegevoegd ", $content="User: " . $ar['voornaam'] . " " . $ar['achternaam'] . " is toegevoegd", $time=0);
            $res->addVar('page', $page);
            $res->send();
        }
    }


    

    function doDeleteUser($params)
    {
        global $app;
        $view = new viewUsers();
        $res = new Response();
        //hier delete je de user aan de hand van welke record is aangeklikt
        $r_id = $params['record_id'];
        $user_id = $params['user_id'];
  

        $model = new modelUser();
        $model->deleteRecord($r_id);

        $modelEvaluatie = new modelUserInfo();
        $modelEvaluatie->deleteEvaluaties($user_id);

        $modelUser = new modelFWUsers();
        $result2 = $modelUser->getById($user_id);

        $wp_id = $result2->wp_id;
        
        $customer_id = $result2->customer_id;
        $app_id = 5;
        $modelUser->removeUserSymLink($wp_id, $customer_id, $app_id);



        $page = array();
        $page['#showEvaluatie'] =  $view->showUserTableBegeleider();//hier kan je ook checken of de juiste variables worden meegegeven
        toast($title="User verwijderd ", $content="De user is verwijderd", $time=0);
        $res->addVar('page', $page);
        $res->send();

    }
    function stagiarAfronden($params)
    {   
        global $app;
        $id = $params['ID'];
        $user_id = $params['user_id'];
        $view = new viewUsers();
        $res = new Response();
        $model = new modelUser();
        
        $mailTemplate = new mail();
        $mail = $mailTemplate->mailTemplate();
        
        $modelEvaluatie = new modelUserInfo();
        $array = array();
        $array['user_id'] = $user_id;
        $array ['naam_evaluatie'] = "Eind evaluatie";
        $array ['evaluatie'] = $app->post['evaluatie'];
        $array ['beoordeling'] = $app->post['beoordeling'];
        $array ['datum'] = $app->post['date'];
        $modelEvaluatie->addRecord($array);

        $email = $app->post['email'];
        $voornaam = $app->post['voornaam'];
        $achternaam = $app->post['achternaam'];

        $to = $email;
        $message = $mail;
        $headers = "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Reply-To: dev@silvas.nl <dev@silvas.nl>\r\n";
        $headers .= "Return-Path: dev@silvas.nl <dev@silvas.nl>\r\n";
        $headers .= "From: Evaluatie app Silvas <dev@silvas.nl>\r\n"; 
        $subject = "Hey ".$voornaam. ' ' . $achternaam." je eindevaluatie is toegevoegd!";
        fw_mail($to, $subject, $message, $headers,  $attachments = array());
        $ar = array();
        $ar ['stageAfgerond'] = 1;
        $model->updateRecord($ar, $id);
        $page = array();
        $page['#showEvaluatie'] =  $view->showUserTableBegeleider();//hier kan je ook checken of de juiste variables worden meegegeven
        $res->addVar('page', $page);
        $res->send();

    }
    function profielBewerken($params)
    {   
        global $app;
        $res = new Response();
        $id = $params['ID'];
        $model = new modelUser();
        $array = array();
        $array['voornaam'] = $app->post['voornaam'];
        $array['achternaam'] = $app->post['achternaam'];
        $array['email'] = $app->post['email'];
        $array['extra_info'] = $app->post['extra_info'];
        $array['opleiding'] = $app->post['opleiding'];
        $array['noodnummer'] = $app->post['noodnummer'];
        $model->updateRecord($array, $id);

        
        $res->send();
    }

    function uploadFile($params){
        $class_files = new modelFWFiles();
        $user_id = getUserId();

       
        // stel een TAG in op 5. Je kunt tags gebruiken om te filteren
        $tags[1] = 5;
        $files = $class_files->getByMultipleKeys(array('user_id'=>$user_id));
        foreach($files as $file){
            $file_id = $file->id;;
            $class_files->deleteFileById($file_id);
        }

        $result = $class_files->doUploadFiles($_FILES['files'],$tags, 1,5000000,'','');
        ?>
        <script>
            location.href = '/';
        </script>
        <?php
        
    }
    function ophalenFile(){
        global $app;
        ob_start();
        $class_files = new modelFWFiles();
        $user_id = getUserId();
        //$files_of_user = $class_files->getFilesOfUser(getUserID());
        
        $files = $class_files->getByMultipleKeys(array('user_id'=>$user_id));
        foreach ($files as $file){
        ?><img src="<?php print $class_files->getFileURL ($file->id) ?>" alt="Girl in a jacket" width="500" height="600"><?
        // $file_id = $file->id;;
        // $class_files->deleteFileById($file_id);
        }        

    }

}

?>