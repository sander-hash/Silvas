<?PHP 

class controllerSolliciteren extends DefaultController
{

    function __construct()
    {
        
    }

    function showSolliciterenForm($params){
        global $app;
        $view = new viewSolliciteren();              
        $app->content = $view->showSolliciterenBijSilvas($params);
    }
    function sollicitatieVerwijderen($params)
    {
        global $app;
        $view = new viewSolliciteren();
        $res = new Response();
        //hier delete je de user aan de hand van welke record is aangeklikt
        $id = $params['id'];
        $model = new modelSolliciteren();
        $model->deleteRecord($id);

        $page = array();
        $page['#solliciteren'] =  $view->showSolliciterenBijSilvas($params);//hier kan je ook checken of de juiste variables worden meegegeven
        toast($title="User verwijderd ", $content="De user is verwijderd", $time=0);
        $res->addVar('page', $page);
        $res->send();

    }

    function saveForm(){
        
        // INT id
        // STRING data
        // INT ctime, default = 0; 
        // INT status , defautt 0 = Nog niet afgehandeld , 1 = afgehandeld niet goedgekeurd , 2 = afgehandeld goedgekeurd
        global $app;
        $view = new viewSolliciteren();
        $res = new Response();
        $model = new modelSolliciteren();
        $ar = array();
        $ar ['ctime'] = current_time('timestamp');
        $ar ['voornaam'] = $app->post['voornaam'];
        $ar ['achternaam'] = $app->post['achternaam'];
        $ar ['emailadres'] = $app->post['email'];
        $ar ['opmerking'] = $app->post['extra_info'];
        $ar ['opleiding'] = $app->post['opleiding'];
        $ar ['school'] = $app->post['school'];
        $ar ['leerjaar'] = $app->post['leerjaar'];
        $ar ['customer_id'] = $app->post['customer_id'];
        

        $model->addRecord($ar);
        $page = array();
        $page['#solliciteren'] = $view->showSolliciterenBijSilvas($params);//hier kan je ook checken of de juiste variables worden meegegeven

        toast($title="Sollicitatie verstuurd ", $content="Bedankt! " . $ar['voornaam'] . " " . $ar['achternaam'] . " Uw sollicitatie is verstuurd", $time=0);
        $res->addVar('page', $page);
        $res->send();
        }
    }




